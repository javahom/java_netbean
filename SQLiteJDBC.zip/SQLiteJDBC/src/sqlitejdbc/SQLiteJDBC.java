/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqlitejdbc;
import java.sql.*;
/**
 *
 * @author User
 */
public class SQLiteJDBC {
  public static void main( String args[] ) {
      Connection c = null;
      Statement stat = null;
      
      try {
         Class.forName("org.sqlite.JDBC");
         //c = DriverManager.getConnection("jdbc:sqlite:test.db");
         c = DriverManager.getConnection("jdbc:sqlite::memory:");
         c.setAutoCommit(false);
            stat = c.createStatement();
            ResultSet rs = stat.executeQuery( "select (5+2)*3");
             System.out.println(rs.getDouble(1));
            stat.close();
            c.close();
      } catch ( Exception e ) {
         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
         System.exit(0);
      }
      System.out.println("Opened database successfully");
   }
}
